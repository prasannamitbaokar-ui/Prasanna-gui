/*
    ================================================================
                    PRASANNA'S CALCULATOR
    C++ / Qt 6 Widgets Project
    ---------------------------------------------------------------
    Modules:
      1. Standard calculator
      2. Scientific calculator
      3. Shannon entropy calculator
      4. Entropy units: bits, nats and Hartleys
    ================================================================
*/

#include <QApplication>
#include <QMainWindow>
#include <QWidget>
#include <QTabWidget>
#include <QLineEdit>
#include <QPushButton>
#include <QLabel>
#include <QGridLayout>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QComboBox>
#include <QMessageBox>
#include <QGroupBox>
#include <QFrame>
#include <QFont>
#include <QStringList>
#include <QRegularExpression>
#include <QDoubleValidator>
#include <cmath>
#include <functional>
#include <stdexcept>
#include <limits>

// ================================================================
// SECTION 1: MATHEMATICAL CONSTANTS
// ================================================================

namespace MathConstants
{
    constexpr double PI = 3.14159265358979323846;
    constexpr double E  = 2.71828182845904523536;
    constexpr double EPSILON = 1e-12;
}

// ================================================================
// SECTION 2: EXPRESSION PARSER
// Handles arithmetic, brackets, powers, factorials and functions.
// ================================================================

class ExpressionParser
{
private:
    QString expression;
    int position;
    bool useDegrees;

    void skipSpaces()
    {
        while (position < expression.length()
               && expression[position].isSpace())
        {
            ++position;
        }
    }

    bool consume(QChar character)
    {
        skipSpaces();

        if (position < expression.length()
            && expression[position] == character)
        {
            ++position;
            return true;
        }

        return false;
    }

    QString readIdentifier()
    {
        skipSpaces();

        int start = position;

        while (position < expression.length()
               && expression[position].isLetter())
        {
            ++position;
        }

        return expression.mid(start, position - start).toLower();
    }

    double parseExpression()
    {
        double value = parseTerm();

        while (true)
        {
            if (consume('+'))
            {
                value += parseTerm();
            }
            else if (consume('-'))
            {
                value -= parseTerm();
            }
            else
            {
                return value;
            }
        }
    }

    double parseTerm()
    {
        double value = parsePower();

        while (true)
        {
            if (consume('*'))
            {
                value *= parsePower();
            }
            else if (consume('/'))
            {
                double divisor = parsePower();

                if (std::abs(divisor) < MathConstants::EPSILON)
                {
                    throw std::runtime_error("Division by zero is not allowed.");
                }

                value /= divisor;
            }
            else
            {
                return value;
            }
        }
    }

    double parsePower()
    {
        double value = parseUnary();

        if (consume('^'))
        {
            double exponent = parsePower();
            value = std::pow(value, exponent);
        }

        return value;
    }

    double parseUnary()
    {
        if (consume('+'))
        {
            return parseUnary();
        }

        if (consume('-'))
        {
            return -parseUnary();
        }

        return parsePrimary();
    }

    double parseNumber()
    {
        skipSpaces();

        int start = position;
        bool decimalPointSeen = false;

        while (position < expression.length())
        {
            QChar current = expression[position];

            if (current.isDigit())
            {
                ++position;
            }
            else if (current == '.' && !decimalPointSeen)
            {
                decimalPointSeen = true;
                ++position;
            }
            else
            {
                break;
            }
        }

        if (start == position)
        {
            throw std::runtime_error("A valid number was expected.");
        }

        bool conversionOk = false;
        double number = expression.mid(start, position - start)
                            .toDouble(&conversionOk);

        if (!conversionOk)
        {
            throw std::runtime_error("Invalid numeric value.");
        }

        return number;
    }

    double factorial(double value)
    {
        if (value < 0
            || std::floor(value) != value
            || value > 170)
        {
            throw std::runtime_error(
                "Factorial accepts integers from 0 to 170.");
        }

        double result = 1.0;

        for (int i = 2; i <= static_cast<int>(value); ++i)
        {
            result *= i;
        }

        return result;
    }

    double parseFunctionArgument()
    {
        if (!consume('('))
        {
            throw std::runtime_error(
                "Write a function argument inside parentheses.");
        }

        double argument = parseExpression();

        if (!consume(')'))
        {
            throw std::runtime_error("A closing parenthesis is missing.");
        }

        return argument;
    }

    double parseTrigonometricFunction(const QString &function,
                                      double value)
    {
        double radians = useDegrees
            ? value * MathConstants::PI / 180.0
            : value;

        if (function == "sin")
        {
            return std::sin(radians);
        }

        if (function == "cos")
        {
            return std::cos(radians);
        }

        if (function == "tan")
        {
            if (std::abs(std::cos(radians)) < 1e-12)
            {
                throw std::runtime_error(
                    "Tangent is undefined at this angle.");
            }

            return std::tan(radians);
        }

        if (function == "asin" || function == "acos")
        {
            if (value < -1.0 || value > 1.0)
            {
                throw std::runtime_error(
                    "asin and acos require input between -1 and 1.");
            }
        }

        double result = 0.0;

        if (function == "asin")
        {
            result = std::asin(value);
        }
        else if (function == "acos")
        {
            result = std::acos(value);
        }
        else
        {
            result = std::atan(value);
        }

        return useDegrees
            ? result * 180.0 / MathConstants::PI
            : result;
    }

    double parsePrimary()
    {
        skipSpaces();

        if (consume('('))
        {
            double value = parseExpression();

            if (!consume(')'))
            {
                throw std::runtime_error("A closing parenthesis is missing.");
            }

            if (consume('!'))
            {
                value = factorial(value);
            }

            return value;
        }

        if (position < expression.length()
            && (expression[position].isDigit()
                || expression[position] == '.'))
        {
            double value = parseNumber();

            if (consume('!'))
            {
                value = factorial(value);
            }

            return value;
        }

        QString function = readIdentifier();

        if (function.isEmpty())
        {
            throw std::runtime_error("A number or function was expected.");
        }

        if (function == "pi")
        {
            return MathConstants::PI;
        }

        if (function == "e")
        {
            return MathConstants::E;
        }

        double argument = parseFunctionArgument();

        if (function == "sin" || function == "cos"
            || function == "tan" || function == "asin"
            || function == "acos" || function == "atan")
        {
            return parseTrigonometricFunction(function, argument);
        }

        if (function == "sqrt")
        {
            if (argument < 0)
            {
                throw std::runtime_error(
                    "Square root of a negative number is not real.");
            }

            return std::sqrt(argument);
        }

        if (function == "log" || function == "ln")
        {
            if (argument <= 0)
            {
                throw std::runtime_error(
                    "Logarithm input must be greater than zero.");
            }

            return function == "log"
                ? std::log10(argument)
                : std::log(argument);
        }

        if (function == "abs")
        {
            return std::abs(argument);
        }

        if (function == "exp")
        {
            return std::exp(argument);
        }

        if (function == "sinh")
        {
            return std::sinh(argument);
        }

        if (function == "cosh")
        {
            return std::cosh(argument);
        }

        if (function == "tanh")
        {
            return std::tanh(argument);
        }

        throw std::runtime_error(
            QString("Unknown function: %1").arg(function).toStdString());
    }

public:
    ExpressionParser(const QString &input, bool degrees)
        : expression(input), position(0), useDegrees(degrees)
    {
    }

    double calculate()
    {
        double result = parseExpression();

        skipSpaces();

        if (position != expression.length())
        {
            throw std::runtime_error(
                "The expression contains an unexpected character.");
        }

        if (!std::isfinite(result))
        {
            throw std::runtime_error(
                "The result is undefined or outside the supported range.");
        }

        return result;
    }
};

// ================================================================
// SECTION 3: ENTROPY CALCULATION UTILITIES
// ================================================================

struct EntropyResults
{
    double bits = 0.0;
    double nats = 0.0;
    double hartleys = 0.0;
};

class EntropyCalculator
{
public:
    static bool validateProbabilities(const QList<double> &probabilities,
                                      QString &errorMessage)
    {
        if (probabilities.isEmpty())
        {
            errorMessage = "Enter at least one probability.";
            return false;
        }

        double total = 0.0;

        for (double probability : probabilities)
        {
            if (!std::isfinite(probability)
                || probability < 0.0
                || probability > 1.0)
            {
                errorMessage =
                    "Every probability must be between 0 and 1.";
                return false;
            }

            total += probability;
        }

        if (std::abs(total - 1.0) > 1e-8)
        {
            errorMessage =
                QString("Probabilities must sum to 1. Current sum: %1")
                    .arg(total, 0, 'g', 12);
            return false;
        }

        return true;
    }

    static EntropyResults calculate(const QList<double> &probabilities)
    {
        EntropyResults result;

        for (double probability : probabilities)
        {
            // By convention, 0 * log(0) contributes zero to entropy.
            if (probability <= 0.0)
            {
                continue;
            }

            result.bits -= probability * std::log2(probability);
            result.nats -= probability * std::log(probability);
            result.hartleys -= probability * std::log10(probability);
        }

        return result;
    }

    static double bitsToNats(double bits)
    {
        return bits * std::log(2.0);
    }

    static double bitsToHartleys(double bits)
    {
        return bits * std::log10(2.0);
    }

    static double natsToBits(double nats)
    {
        return nats / std::log(2.0);
    }

    static double natsToHartleys(double nats)
    {
        return nats / std::log(10.0);
    }

    static double hartleysToBits(double hartleys)
    {
        return hartleys / std::log10(2.0);
    }

    static double hartleysToNats(double hartleys)
    {
        return hartleys * std::log(10.0);
    }
};

// ================================================================
// SECTION 4: MAIN WINDOW AND USER INTERFACE
// ================================================================

class CalculatorWindow : public QMainWindow
{
private:
    QTabWidget *tabWidget = nullptr;

    QLineEdit *standardDisplay = nullptr;
    QLineEdit *scientificDisplay = nullptr;

    QLineEdit *probabilityInput = nullptr;
    QLabel *entropyResultLabel = nullptr;

    QLineEdit *conversionInput = nullptr;
    QComboBox *conversionFrom = nullptr;
    QComboBox *conversionTo = nullptr;
    QLabel *conversionResultLabel = nullptr;

    QComboBox *angleMode = nullptr;

    QString lastAnswer = "0";

    // ------------------------------------------------------------
    // Create a consistently styled button.
    // ------------------------------------------------------------
    QPushButton *createButton(const QString &text,
                              const std::function<void()> &action,
                              const QString &objectName = QString())
    {
        QPushButton *button = new QPushButton(text);

        if (!objectName.isEmpty())
        {
            button->setObjectName(objectName);
        }

        button->setMinimumHeight(42);

        connect(button, &QPushButton::clicked,
                this, [action]()
        {
            action();
        });

        return button;
    }

    // ------------------------------------------------------------
    // Apply the result of an expression to the display.
    // ------------------------------------------------------------
    void evaluateExpression(QLineEdit *display, bool scientificMode)
    {
        QString input = display->text().trimmed();

        if (input.isEmpty())
        {
            return;
        }

        // Handle a simple percentage such as 25%.
        if (input.endsWith('%'))
        {
            bool validNumber = false;

            double number = input.left(input.length() - 1)
                                .trimmed()
                                .toDouble(&validNumber);

            if (validNumber)
            {
                input = QString::number(number / 100.0, 'g', 15);
            }
            else
            {
                QMessageBox::information(
                    this,
                    "Percentage",
                    "For a simple percentage, enter a number such as 25%.\n"
                    "For expressions, use /100.");
                return;
            }
        }

        try
        {
            bool degrees = scientificMode
                && angleMode
                && angleMode->currentText() == "Degrees";

            ExpressionParser parser(input, degrees);
            double answer = parser.calculate();

            QString formattedAnswer =
                QString::number(answer, 'g', 15);

            display->setText(formattedAnswer);
            lastAnswer = formattedAnswer;
        }
        catch (const std::exception &exception)
        {
            QMessageBox::warning(
                this,
                "Calculation Error",
                QString::fromUtf8(exception.what()));
        }
    }

    // ------------------------------------------------------------
    // Add a calculator key to a grid.
    // ------------------------------------------------------------
    void addCalculatorKey(QGridLayout *grid,
                          const QString &keyText,
                          int row,
                          int column,
                          QLineEdit *display,
                          bool scientificMode)
    {
        QPushButton *key = createButton(
            keyText,
            [this, display, keyText, scientificMode]()
            {
                handleCalculatorKey(display, keyText, scientificMode);
            },
            keyText == "=" ? "equals" :
            keyText == "C" ? "danger" : QString());

        grid->addWidget(key, row, column);
    }

    // ------------------------------------------------------------
    // Respond to calculator key presses.
    // ------------------------------------------------------------
    void handleCalculatorKey(QLineEdit *display,
                             const QString &key,
                             bool scientificMode)
    {
        if (key == "C")
        {
            display->clear();
            return;
        }

        if (key == "⌫")
        {
            display->backspace();
            return;
        }

        if (key == "=")
        {
            evaluateExpression(display, scientificMode);
            return;
        }

        if (key == "Ans")
        {
            display->insert(lastAnswer);
            return;
        }

        if (key == "π")
        {
            display->insert("pi");
            return;
        }

        if (key == "×")
        {
            display->insert("*");
            return;
        }

        if (key == "÷")
        {
            display->insert("/");
            return;
        }

        if (key == "−")
        {
            display->insert("-");
            return;
        }

        display->insert(key);
    }

    // ------------------------------------------------------------
    // Build the standard calculator tab.
    // ------------------------------------------------------------
    QWidget *createStandardTab()
    {
        QWidget *page = new QWidget;
        QVBoxLayout *mainLayout = new QVBoxLayout(page);

        QLabel *heading = new QLabel("Standard Calculator");
        heading->setObjectName("sectionHeading");

        standardDisplay = new QLineEdit;
        standardDisplay->setAlignment(Qt::AlignRight);
        standardDisplay->setMinimumHeight(58);
        standardDisplay->setPlaceholderText("Enter an arithmetic expression");

        mainLayout->addWidget(heading);
        mainLayout->addWidget(standardDisplay);

        QGridLayout *keyGrid = new QGridLayout;
        keyGrid->setSpacing(8);

        QStringList keys =
        {
            "7", "8", "9", "÷",
            "4", "5", "6", "×",
            "1", "2", "3", "−",
            "0", ".", "(", ")",
            "+", "^", "%", "Ans",
            "C", "⌫", "="
        };

        int columns = 4;

        for (int index = 0; index < keys.size(); ++index)
        {
            int row = index / columns;
            int column = index % columns;

            addCalculatorKey(
                keyGrid,
                keys[index],
                row,
                column,
                standardDisplay,
                false);
        }

        mainLayout->addLayout(keyGrid);

        QLabel *helpText = new QLabel(
            "Examples: (12+8)*3, 2^5, 25%, or 100/4");
        helpText->setWordWrap(true);
        helpText->setObjectName("helpText");

        mainLayout->addWidget(helpText);
        mainLayout->addStretch();

        return page;
    }

    // ------------------------------------------------------------
    // Build the scientific calculator tab.
    // ------------------------------------------------------------
    QWidget *createScientificTab()
    {
        QWidget *page = new QWidget;
        QVBoxLayout *mainLayout = new QVBoxLayout(page);

        QLabel *heading = new QLabel("Scientific Calculator");
        heading->setObjectName("sectionHeading");

        scientificDisplay = new QLineEdit;
        scientificDisplay->setAlignment(Qt::AlignRight);
        scientificDisplay->setMinimumHeight(58);
        scientificDisplay->setPlaceholderText(
            "Example: sin(30)+sqrt(16)+log(100)");

        mainLayout->addWidget(heading);
        mainLayout->addWidget(scientificDisplay);

        QHBoxLayout *modeLayout = new QHBoxLayout;
        QLabel *modeLabel = new QLabel("Trigonometry angle mode:");

        angleMode = new QComboBox;
        angleMode->addItems({"Degrees", "Radians"});
        angleMode->setMinimumWidth(140);

        modeLayout->addWidget(modeLabel);
        modeLayout->addWidget(angleMode);
        modeLayout->addStretch();

        mainLayout->addLayout(modeLayout);

        QGridLayout *keyGrid = new QGridLayout;
        keyGrid->setSpacing(7);

        QStringList keys =
        {
            "sin(", "cos(", "tan(", "asin(", "acos(",
            "atan(", "sqrt(", "log(", "ln(", "exp(",
            "sinh(", "cosh(", "tanh(", "abs(", "^",
            "π", "e", "!", "(", ")",
            "7", "8", "9", "÷", "C",
            "4", "5", "6", "×", "⌫",
            "1", "2", "3", "−", "=",
            "0", ".", "+", "Ans", " "
        };

        int columns = 5;

        for (int index = 0; index < keys.size(); ++index)
        {
            QString key = keys[index];

            if (key.trimmed().isEmpty())
            {
                continue;
            }

            int row = index / columns;
            int column = index % columns;

            addCalculatorKey(
                keyGrid,
                key,
                row,
                column,
                scientificDisplay,
                true);
        }

        mainLayout->addLayout(keyGrid);

        QLabel *functionHelp = new QLabel(
            "Functions: sin, cos, tan, asin, acos, atan, sqrt, log, ln, "
            "exp, sinh, cosh, tanh and abs. Use parentheses after functions. "
            "Example: sin(30), log(100), 5! or 2^8.");
        functionHelp->setWordWrap(true);
        functionHelp->setObjectName("helpText");

        mainLayout->addWidget(functionHelp);
        mainLayout->addStretch();

        return page;
    }

    // ------------------------------------------------------------
    // Read comma-separated probabilities from the input field.
    // ------------------------------------------------------------
    QList<double> readProbabilities(bool &valid)
    {
        QList<double> values;
        valid = false;

        QString text = probabilityInput->text().trimmed();

        if (text.isEmpty())
        {
            return values;
        }

        QStringList pieces =
            text.split(',', Qt::SkipEmptyParts);

        for (const QString &piece : pieces)
        {
            bool ok = false;
            double value = piece.trimmed().toDouble(&ok);

            if (!ok)
            {
                return {};
            }

            values.append(value);
        }

        valid = !values.isEmpty();
        return values;
    }

    // ------------------------------------------------------------
    // Calculate Shannon entropy in three different units.
    // ------------------------------------------------------------
    void calculateEntropy()
    {
        bool validInput = false;
        QList<double> probabilities = readProbabilities(validInput);

        if (!validInput)
        {
            QMessageBox::warning(
                this,
                "Invalid Input",
                "Enter numeric probabilities separated by commas.\n"
                "Example: 0.5, 0.5");
            return;
        }

        QString validationError;

        if (!EntropyCalculator::validateProbabilities(
                probabilities, validationError))
        {
            QMessageBox::warning(
                this,
                "Probability Validation",
                validationError);
            return;
        }

        EntropyResults result =
            EntropyCalculator::calculate(probabilities);

        entropyResultLabel->setText(
            "SHANNON ENTROPY RESULTS\n\n"
            "Entropy in bits:       "
            + QString::number(result.bits, 'g', 12)
            + " bits\n\n"
            "Entropy in nats:       "
            + QString::number(result.nats, 'g', 12)
            + " nats\n\n"
            "Entropy in Hartleys:   "
            + QString::number(result.hartleys, 'g', 12)
            + " Hartleys\n\n"
            "The three values describe the same uncertainty "
            "using different logarithm bases.");
    }

    // ------------------------------------------------------------
    // Convert a numeric entropy value between bits, nats and
    // Hartleys. This converts units; it does not recalculate a
    // probability distribution.
    // ------------------------------------------------------------
    void convertEntropyUnit()
    {
        bool ok = false;
        double inputValue = conversionInput->text().trimmed().toDouble(&ok);

        if (!ok || !std::isfinite(inputValue) || inputValue < 0.0)
        {
            QMessageBox::warning(
                this,
                "Invalid Value",
                "Enter a valid non-negative entropy value.");
            return;
        }

        QString from = conversionFrom->currentText();
        QString to = conversionTo->currentText();

        double valueInBits = inputValue;

        if (from == "Nats")
        {
            valueInBits = EntropyCalculator::natsToBits(inputValue);
        }
        else if (from == "Hartleys")
        {
            valueInBits = EntropyCalculator::hartleysToBits(inputValue);
        }

        double convertedValue = valueInBits;

        if (to == "Nats")
        {
            convertedValue = EntropyCalculator::bitsToNats(valueInBits);
        }
        else if (to == "Hartleys")
        {
            convertedValue = EntropyCalculator::bitsToHartleys(valueInBits);
        }

        conversionResultLabel->setText(
            QString("%1 %2 = %3 %4")
                .arg(inputValue, 0, 'g', 12)
                .arg(from)
                .arg(convertedValue, 0, 'g', 12)
                .arg(to));
    }

    // ------------------------------------------------------------
    // Build the entropy-unit conversion panel.
    // ------------------------------------------------------------
    QWidget *createConversionPanel()
    {
        QWidget *panel = new QWidget;
        QVBoxLayout *layout = new QVBoxLayout(panel);

        QLabel *heading = new QLabel("Bits / Nats / Hartleys Converter");
        heading->setObjectName("sectionHeading");

        QLabel *description = new QLabel(
            "Convert a known entropy value between the three units.");
        description->setWordWrap(true);

        conversionInput = new QLineEdit;
        conversionInput->setPlaceholderText("Enter entropy value, e.g. 1");

        conversionFrom = new QComboBox;
        conversionFrom->addItems({"Bits", "Nats", "Hartleys"});

        conversionTo = new QComboBox;
        conversionTo->addItems({"Nats", "Bits", "Hartleys"});

        QGridLayout *form = new QGridLayout;
        form->addWidget(new QLabel("Value:"), 0, 0);
        form->addWidget(conversionInput, 0, 1);
        form->addWidget(new QLabel("Convert from:"), 1, 0);
        form->addWidget(conversionFrom, 1, 1);
        form->addWidget(new QLabel("Convert to:"), 2, 0);
        form->addWidget(conversionTo, 2, 1);

        QPushButton *convertButton = createButton(
            "Convert Units",
            [this]() { convertEntropyUnit(); },
            "equals");

        conversionResultLabel = new QLabel("Conversion result appears here.");
        conversionResultLabel->setWordWrap(true);
        conversionResultLabel->setObjectName("resultPanel");

        layout->addWidget(heading);
        layout->addWidget(description);
        layout->addLayout(form);
        layout->addWidget(convertButton);
        layout->addWidget(conversionResultLabel);
        layout->addStretch();

        return panel;
    }

    // ------------------------------------------------------------
    // Build the main entropy page with calculator and converter.
    // ------------------------------------------------------------
    QWidget *createEntropyTab()
    {
        QWidget *page = new QWidget;
        QVBoxLayout *layout = new QVBoxLayout(page);

        QTabWidget *entropyTabs = new QTabWidget;
        entropyTabs->addTab(createEntropyPanelOnly(), "Calculate Entropy");
        entropyTabs->addTab(createConversionPanel(), "Convert Units");

        layout->addWidget(entropyTabs);
        return page;
    }

    QWidget *createEntropyPanelOnly()
    {
        return createEntropyTabContent();
    }

    QWidget *createEntropyTabContent()
    {
        QWidget *page = new QWidget;
        QVBoxLayout *mainLayout = new QVBoxLayout(page);

        QLabel *heading = new QLabel("Shannon Entropy Calculator");
        heading->setObjectName("sectionHeading");

        QLabel *instructions = new QLabel(
            "Enter probabilities separated by commas, for example 0.5, 0.5. "
            "The values must sum to 1.");
        instructions->setWordWrap(true);

        probabilityInput = new QLineEdit;
        probabilityInput->setPlaceholderText("0.5, 0.5");

        QHBoxLayout *buttons = new QHBoxLayout;
        buttons->addWidget(createButton(
            "Calculate Entropy",
            [this]() { calculateEntropy(); },
            "equals"));
        buttons->addWidget(createButton(
            "Clear",
            [this]()
            {
                probabilityInput->clear();
                entropyResultLabel->clear();
            },
            "danger"));

        entropyResultLabel = new QLabel("Results appear here.");
        entropyResultLabel->setWordWrap(true);
        entropyResultLabel->setTextInteractionFlags(Qt::TextSelectableByMouse);
        entropyResultLabel->setObjectName("resultPanel");

        QLabel *formulas = new QLabel(
            "Bits: H = -Σ p log₂(p)\n"
            "Nats: H = -Σ p ln(p)\n"
            "Hartleys: H = -Σ p log₁₀(p)\n\n"
            "A probability of zero contributes zero to entropy.");
        formulas->setWordWrap(true);
        formulas->setObjectName("helpText");

        mainLayout->addWidget(heading);
        mainLayout->addWidget(instructions);
        mainLayout->addWidget(probabilityInput);
        mainLayout->addLayout(buttons);
        mainLayout->addWidget(entropyResultLabel);
        mainLayout->addWidget(formulas);
        mainLayout->addStretch();

        return page;
    }

    // ------------------------------------------------------------
    // Apply application-wide styling.
    // ------------------------------------------------------------
    void applyDarkTheme()
    {
        setStyleSheet(R"(
            QMainWindow, QWidget {
                background-color: #111827;
                color: #e5e7eb;
                font-family: "Segoe UI", Arial;
                font-size: 14px;
            }

            QLabel#sectionHeading {
                color: #60a5fa;
                font-size: 19px;
                font-weight: bold;
                padding: 5px;
            }

            QLabel#helpText {
                color: #9ca3af;
                padding: 5px;
            }

            QLineEdit {
                background-color: #1f2937;
                color: #f9fafb;
                border: 1px solid #475569;
                border-radius: 8px;
                padding: 11px;
                font-size: 17px;
            }

            QPushButton {
                background-color: #263449;
                color: #f9fafb;
                border: 1px solid #475569;
                border-radius: 8px;
                padding: 9px;
                min-height: 25px;
            }

            QPushButton:hover {
                background-color: #374b67;
            }

            QPushButton#equals {
                background-color: #2563eb;
                color: white;
                font-weight: bold;
            }

            QPushButton#danger {
                background-color: #7f1d1d;
            }

            QLabel#resultPanel {
                background-color: #1f2937;
                border: 1px solid #374151;
                border-radius: 9px;
                padding: 16px;
                font-size: 16px;
            }

            QTabWidget::pane {
                border: 1px solid #374151;
                border-radius: 8px;
                padding: 8px;
            }

            QTabBar::tab {
                background-color: #1f2937;
                padding: 10px 18px;
                margin-right: 4px;
                border-radius: 6px;
            }

            QTabBar::tab:selected {
                background-color: #2563eb;
                color: white;
            }

            QComboBox {
                background-color: #1f2937;
                border: 1px solid #475569;
                border-radius: 7px;
                padding: 8px;
            }

            QGroupBox {
                border: 1px solid #475569;
                border-radius: 8px;
                margin-top: 10px;
                padding: 10px;
                font-weight: bold;
            }

            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 4px;
                color: #93c5fd;
            }
        )");
    }

public:
    CalculatorWindow()
    {
        setWindowTitle("Prasanna's Calculator");
        resize(850, 720);
        setMinimumSize(700, 600);

        QWidget *centralWidget = new QWidget;
        QVBoxLayout *rootLayout = new QVBoxLayout(centralWidget);
        rootLayout->setContentsMargins(18, 18, 18, 18);
        rootLayout->setSpacing(12);

        QLabel *appTitle = new QLabel("PRASANNA'S CALCULATOR");
        appTitle->setAlignment(Qt::AlignCenter);
        appTitle->setStyleSheet(
            "font-size: 25px; font-weight: bold; color: #60a5fa; "
            "letter-spacing: 2px;");

        QLabel *subtitle = new QLabel(
            "Standard Mathematics  •  Scientific Functions  •  Information Entropy");
        subtitle->setAlignment(Qt::AlignCenter);
        subtitle->setStyleSheet("color: #9ca3af;");

        tabWidget = new QTabWidget;
        tabWidget->addTab(createStandardTab(), "Standard");
        tabWidget->addTab(createScientificTab(), "Scientific");
        tabWidget->addTab(createEntropyTab(), "Entropy");

        rootLayout->addWidget(appTitle);
        rootLayout->addWidget(subtitle);
        rootLayout->addWidget(tabWidget);

        setCentralWidget(centralWidget);
        applyDarkTheme();
    }
};

// ================================================================
// SECTION 5: APPLICATION ENTRY POINT
// ================================================================

int main(int argc, char *argv[])
{
    QApplication application(argc, argv);

    QApplication::setApplicationName("Prasanna's Calculator");
    QApplication::setOrganizationName("Prasanna");

    CalculatorWindow calculator;
    calculator.show();

    return application.exec();
}
