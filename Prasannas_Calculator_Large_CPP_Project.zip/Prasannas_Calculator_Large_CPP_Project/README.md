# Prasanna's Calculator — Expanded C++ Project

This expanded version is organized into sections and includes:
- Standard arithmetic calculator
- Scientific functions and degree/radian mode
- Shannon entropy from a probability distribution
- Entropy unit conversion: bits, nats, Hartleys
- Input validation and error messages
- Dark Qt Widgets interface

## Build using Qt Creator
1. Install Qt 6 with Qt Creator and a supported compiler kit.
2. Extract this ZIP archive.
3. Open `CMakeLists.txt` in Qt Creator.
4. Select your Qt 6 compiler kit and configure the project.
5. Build and run.

## Examples
- Standard: `(12+8)*3` -> 60
- Scientific: `sin(30)` in Degrees mode -> 0.5
- Scientific: `sqrt(81)` -> 9
- Scientific: `log(100)` -> 2
- Scientific: `5!` -> 120
- Entropy probabilities: `0.5, 0.5` -> 1 bit, about 0.693147 nats, about 0.301030 Hartleys

## Important
The project source is intentionally expanded with comments and separated sections to be easier to study. Qt 6 is required. Compile the project in Qt Creator and resolve any compiler messages for your installed Qt version.
